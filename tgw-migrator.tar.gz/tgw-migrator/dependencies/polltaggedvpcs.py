import boto3
import sqlite3
import sys
import time
import threading
from region import region
from sqlite3 import Error

def polltaggedvpcs(db_file,tgw_id,region):
    # Creating boto3 instances
    ec2_r = boto3.resource('ec2', region_name = region)
    ec2_c = boto3.client('ec2', region_name = region)


    print("\n")
    print("====== Attaching VPCs that are tagged ======")

    filters = [{'Name':'tag:attach-tgw', 'Values':['true','True','TRUE']}]
    vpcs = ec2_r.vpcs.filter(Filters=filters)
    conn = sqlite3.connect(db_file)
    c = conn.cursor()

    for vpc in vpcs:
        c.execute('SELECT vpc_id FROM tgw_migration WHERE vpc_id LIKE ?', ('%'+vpc.id+'%',))
        if c.fetchone() == None:

            try:
                response = ec2_c.describe_vpcs(
                    VpcIds=[vpc.id]
                )
                vpc_cidr_block = response['Vpcs'][0]['CidrBlock']

                # Make sure there is a subnet in each AZ for this region, then pick the first three subnets to use in the attachment
                response = ec2_c.describe_availability_zones()
                zones = []
                for zone in response['AvailabilityZones']:
                    zones.append(zone['ZoneName'])

                subnets = ec2_r.subnets.filter(Filters=[{'Name':'vpc-id','Values': [vpc.id]}])
                subnets_ids = []
                for subnet in subnets:
                    subnets_ids.append(subnet.id)

                subnets_info = ec2_c.describe_subnets(
                        SubnetIds=subnets_ids
                )

                subnets_to_attach = []
                for zone in zones:
                    for subnet in subnets_info['Subnets']:
                        if subnet['AvailabilityZone'] == zone:
                            subnets_to_attach.append(subnet['SubnetId'])
                            break
                
                # Compare number of AZs to the number of subnets; they should be equal. If not rollback
                if len(zones) == len(subnets_to_attach):
                    response = ec2_c.create_transit_gateway_vpc_attachment(
                            TransitGatewayId=tgw_id,
                            VpcId=vpc.id,
                            SubnetIds=subnets_to_attach
                    )
                    vpc_attachment_id = response['TransitGatewayVpcAttachment']['TransitGatewayAttachmentId']
                    print("attached %s to %s. Adding to DB..." % (vpc.id,tgw_id))
                    c.execute('''INSERT INTO tgw_migration (vpc_id, vpc_cidr, vpc_attachment)
                                VALUES (?,?,?)''', (vpc.id,vpc_cidr_block,vpc_attachment_id))
                    
                else:
                    print("you need at least one subnet per AZ in %s. Ignoring this VPC attachment..." % vpc.id)
            except:
                pass
            
        else:
            pass 

    conn.commit()
    conn.close()