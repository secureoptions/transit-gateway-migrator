import boto3
import sqlite3
import re
import threading
import time
import sys
import os
from region import region
from sqlite3 import Error


def pollspokevpcs(db_file,tgw_id,region):

    # Creating boto3 instances
    ec2_c = boto3.client('ec2', region_name = region)
    ec2_r = boto3.resource('ec2', region_name = region)
    # clear user terminal for better readability
    os.system('clear')
    user_response = raw_input("\n\nDo you want to migrate 'spoke' VPCs from a transit-VPC solution to TGW?\n"
                                  "-----------------------------------------------------------------------\n"
                              "y\\N > ") or "N"
    
    if user_response.lower() == 'y':
        def get_answer():
            user_response = raw_input("\nPlease provide the public IP of ONE of your transit-VPC hub routers\n"
                                    "(If you are running redundant routers, you can choose either one.\n" 
                                    "The public IP should be in the format: 1.2.3.4)\n"
                                    "-----------------------------------------------\n"
                                    "> ")
            m = re.match('^\d{1,3}\.\d{1,3}\.\d{1,3}.\d{1,3}$', user_response)
            if m:
                return user_response
            else:
                print("\nYou must provide a valid IP in the form of 'x.x.x.x'")
                get_answer()

        print("\n")
        cgw = get_answer()

        # Access the db
        conn = sqlite3.connect(db_file)
        c = conn.cursor()
        print("\n")

        try:
            # Describe CGWs matching IP customer provided
            response = ec2_c.describe_customer_gateways(
                Filters = [{
                    'Name':'ip-address',
                    'Values':[cgw]
                    }]
                )

            # Find VPNs associated with CGW id
            response = ec2_c.describe_vpn_connections(
                Filters = [{
                    'Name':'customer-gateway-id',
                    'Values':[response['CustomerGateways'][0]['CustomerGatewayId']]
                    }]
                )

            # For each VPN returned describe its VGW id and append to a list
            vgws = []
            for vpn in response['VpnConnections']:
                vgws.append(vpn['VpnGatewayId'])

            # For each VGW in the list, describe it so we can find out if/what VPC is attached
            response = ec2_c.describe_vpn_gateways(
                Filters = [{
                    'Name':'vpn-gateway-id',
                    'Values':vgws
                    }]
                )

            vpc_attachments=[]
            for vgw in response['VpnGateways']:
                vpc_id = vgw['VpcAttachments'][0]['VpcId']
                c.execute('SELECT vpc_id FROM tgw_migration WHERE vpc_id LIKE ?', ('%'+vpc_id+'%',))
                if c.fetchone() == None:
                    try:
                        response = ec2_c.describe_vpcs(
                            VpcIds = [vpc_id]
                            )
                        
                        vpc_cidr_block = response['Vpcs'][0]['CidrBlock']

                        # Make sure there is a subnet in each AZ for this region, then pick the first three subnets to use in the attachment
                        response = ec2_c.describe_availability_zones()
                        zones = []
                        for zone in response['AvailabilityZones']:
                            zones.append(zone['ZoneName'])

                        subnets = ec2_r.subnets.filter(Filters=[{'Name':'vpc-id','Values': [vpc_id]}])
                        subnets_ids = []
                        for subnet in subnets:
                            subnets_ids.append(subnet.id)

                        subnets_info = ec2_c.describe_subnets(
                                SubnetIds=subnets_ids
                        )

                        subnets_to_attach = []
                        for zone in zones:
                            for subnet in subnets_info['Subnets']:
                                if subnet['AvailabilityZone'] == zone:
                                    subnets_to_attach.append(subnet['SubnetId'])
                                    break
                        
                        # Compare number of AZs to the number of subnets; they should be equal. If not rollback
                        if len(zones) == len(subnets_to_attach):
                            response = ec2_c.create_transit_gateway_vpc_attachment(
                                    TransitGatewayId=tgw_id,
                                    VpcId=vpc_id,
                                    SubnetIds=subnets_to_attach
                            )

                            vpc_attachment_id = response['TransitGatewayVpcAttachment']['TransitGatewayAttachmentId']
                            print("attached %s to %s. Adding to DB..." % (vpc_id,tgw_id))
                            c.execute('''INSERT INTO tgw_migration (vpc_id, vpc_cidr, vpc_attachment)
                                        VALUES (?,?,?)''', (vpc_id,vpc_cidr_block,vpc_attachment_id))
                            
                            vpc_attachments.append(vpc_attachment_id)

                        else:
                            print("you need at least one subnet per AZ in %s. Ignoring this VPC attachment..." % vpc_id)
                    
                    except:
                        pass

                else:
                    pass

 
        except:
            pass                

        conn.commit()
        conn.close()

        if len(vpc_attachments) >= 1:
            print("waiting for all VPC attachments to go from 'pending' to 'available'...")
            def spin_cursor():
                while True:
                        # Make a fancy spinning cursor while waiting waiting on the following TGW to become available (yes, I'm bored...)
                    for cursor in '|/-\\':
                        sys.stdout.write(cursor)
                        sys.stdout.flush()
                        time.sleep(0.1) # adjust this to change the speed
                        sys.stdout.write('\b')
                        if done:
                            return
            spin_thread = threading.Thread(target=spin_cursor)
            done = False
            spin_thread.start()
            for attach in vpc_attachments:
                count = 0            
                while True:
                    response = ec2_c.describe_transit_gateway_vpc_attachments(
                                TransitGatewayAttachmentIds=[attach]
                    )
                    if response['TransitGatewayVpcAttachments'][0]['State'] == 'available':
                        break
                    else:
                        if count >= 300:
                            print("%s is still \"Pending\" after 5 minutes. You may want to manually check on this attachment. Skipping it..." % attach)
                            break
                        else:
                            time.sleep(5)
                            count += 5
            done = True
            spin_thread.join()
        
    elif user_response.lower() == 'n':
        print("\nSkipping any transit-vpc to TGW migration...")
        return
    else:
        print("\nYou must choose 'Y' or 'N' for the question above")
        pollspokevpcs(db_file,tgw_id,region)