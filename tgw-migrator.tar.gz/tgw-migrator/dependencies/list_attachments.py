import os
from prettytable import PrettyTable
from retrieve_items import retrieve_items

def list_attachments(tb):
    os.system('clear')
    # Initialize pretty table
    x = PrettyTable()

    # Create pretty table headers
    x.field_names = [" VPC ID ", " VPC Attachment ID ", " VPC CIDR ", " Owner Account "]

    # Create table of all items in DB
    for i in retrieve_items(tb):
        x.add_row([i, retrieve_items(tb)[i]['VpcAttachmentId'], retrieve_items(tb)[i]['VpcCidr'], retrieve_items(tb)[i]['OwnerAccount']])

    print('\n')
    print(x)