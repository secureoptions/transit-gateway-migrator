import boto3
import glob
import time
import sys
import threading
import os
from region import region
from delete_routes import delete_routes
from retrieve_items import retrieve_items
from unshare_ram import unshare_ram

def detach_vpcs(tb,tgw_id):
    os.system('clear')
    table = tb
    delete_routes(table,tgw_id)
    def break_off(c,acct):
        ec2_c = c
        try:
            # Describe each VPC attachment to make sure they are not in a 'pending' state
            for attach in retrieve_items(table):
                if retrieve_items(table)[attach]['OwnerAccount'] == acct:
                    response = ec2_c.describe_transit_gateway_vpc_attachments(
                        TransitGatewayAttachmentIds=[retrieve_items(table)[attach]['VpcAttachmentId']]
                    )
                    if response['TransitGatewayVpcAttachments'][0]['State'] == "pending":
                        print("\n%s is still in 'pending' state. Attachments must be in\n"
                            "'available' state before they can be deleted...EXITING!\n" % attach[0])
                        sys.exit()

                    print("Detaching %s (%s) from\n"
                        "%s...." % (retrieve_items(table)[attach]['VpcAttachmentId'],attach,tgw_id))
                    ec2_c.delete_transit_gateway_vpc_attachment(
                        TransitGatewayAttachmentId=retrieve_items(table)[attach]['VpcAttachmentId']
                    )
        except:
            print("ERROR: Cannot delete %s (%s) from %s\n"
                "...skipping this attachment\n" % (retrieve_items(table)[attach]['VpcAttachmentId'],attach,tgw_id))
            pass

    def check_status_break_off(ec2_c,acct):
        try:
            def spin_cursor():
                while True:
                        # Make a fancy spinning cursor while waiting waiting on the following TGW to become available (yes, I'm bored...)
                    for cursor in '|/-\\':
                        sys.stdout.write(cursor)
                        sys.stdout.flush()
                        time.sleep(0.1) # adjust this to change the speed
                        sys.stdout.write('\b')
                        if done:
                            return
            spin_thread = threading.Thread(target=spin_cursor)
            # Retrieve items from DB
            items = retrieve_items(table)
            done = False
            spin_thread.start()

            for item in items:
                if items[item]['OwnerAccount'] == acct:

                    print("Waiting on %s to fully delete..." % items[item]['VpcAttachmentId'])
                    count = 0
                    while True:
                        response = ec2_c.describe_transit_gateway_vpc_attachments(
                            TransitGatewayAttachmentIds=[items[item]['VpcAttachmentId']]
                        )
                        if response['TransitGatewayVpcAttachments'][0]['State'] == "deleted":
                            table.delete_item(
                                Key={
                                    'VpcId': item
                                }
                            )
                            break
                        else:
                            if count >= 300:
                                print("%s is still \"Deleting\" after 5 minutes. You may want to\n"
                                    "manually check on this attachment. Skipping it...\n" % items[item]['VpcAttachmentId'])

                                break
                            else:
                                time.sleep(5)
                                count += 5
            done = True
            spin_thread.join()  

        except:
            raise
    
    # Check if there are any secondary AWS accounts with spoke VPCs that need to be attached
    with open('dependencies/accounts.txt','r') as f:
        accounts = f.read()
    accounts = accounts.replace('-','').replace(' ','').replace('\n','')
    accounts = accounts.split(',')

    def get_account_creds(account):
        # Assume role for secondary account
        sts = boto3.client('sts',region_name=region)
        creds = sts.assume_role(
            RoleArn='arn:aws:iam::' + account + ':role/TgwMigratorCrossAccountAccess',
            RoleSessionName='TgwMigratorUpdateDb'
        )

        # Use the retrieved creds above to make API calls
        ec2_c = boto3.client('ec2',
                region_name = region,
                aws_access_key_id = creds['Credentials']['AccessKeyId'],
                aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                aws_session_token = creds['Credentials']['SessionToken']
                )
        ec2_r = boto3.resource('ec2',
                region_name = region,
                aws_access_key_id = creds['Credentials']['AccessKeyId'],
                aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                aws_session_token = creds['Credentials']['SessionToken']
                )
        return ec2_c, ec2_r
    
    if accounts[0] == '' and len(accounts) < 2:
        # There are no secondary accounts.
        # Attach VPCs in parent account
        ec2_c = boto3.client('ec2', region_name = region)
        print("\nChecking parent account for attachments...")
        break_off(ec2_c,'parent account')

        # Check status of VPCs in parent account
        ec2_c = boto3.client('ec2', region_name = region)
        print("\nEnsuring attachments in parent account are fully deleted...")
        check_status_break_off(ec2_c,'parent account')
        
    else:
        # Attach VPCs in parent account
        ec2_c = boto3.client('ec2', region_name = region)
        print("\nChecking parent account for attachments...")
        break_off(ec2_c,'parent account')
        # Attach VPCs in secondary accounts
        for account in accounts:
            if account != '':
                creds = get_account_creds(account)
                print("\nChecking account %s for attachments..." % account)
                break_off(creds[0],account)

        # Check status of VPCs in parent account
        ec2_c = boto3.client('ec2', region_name = region)
        print("\nEnsuring attachments in parent account are fully deleted...")
        check_status_break_off(ec2_c,'parent account')
        
        # Check status of VPCs in secondary accounts
        for account in accounts:
            if account != '':
                print("\nEnsuring attachments in account %s are fully deleted..." % account)
                creds = get_account_creds(account)
                check_status_break_off(creds[0],account)


    os.system('clear')
    second_user_response = raw_input("Attachments have been deleted. Do you want to just deregister\n"
                                         "the TGW or deregister AND delete it? Choose A or B.\n"
                                         "--------------------------------------------------------\n"
                                         "A) Deregister and delete the TGW\n"
                                         "B) Deregister the TGW but don't delete it\n"
                                         "C) Keep TGW registered with this tool\n"
                                         "--------------------------------------------------------\n"
                                        "a\\b\\C> ") or "C"
    unshare_ram(table)
    if second_user_response.lower() == 'a':
        ec2_c = boto3.client('ec2', region_name = region)
        try:
            print("deleting %s..." % tgw_id)
            ec2_c.delete_transit_gateway(
                TransitGatewayId=tgw_id
            )
            table.delete_item(
                Key={
                    'VpcId': 'vpc-xxxx'
                }
            )
            
        except:
            print("\n\nHmm...%s was unable to be deleted. You may try to delete this\n"
                    "connection manually")
            raise
    elif second_user_response.lower() == 'b':
        table.delete_item(
            Key={
                    'VpcId': 'vpc-xxxx'
                }
            )
    elif second_user_response.lower() == 'c':
        try:
            table.update_item(
                Key={
                    'VpcId':'vpc-xxxx'
                },
                AttributeUpdates={
                    'RamShareArn':{
                        'Action':'DELETE'
                        }
                }
                )
        except KeyError:
            pass

    else:
        pass
                