import boto3
import pandas
import sqlite3
import os
from region import region


def deleteroutes(db_file,tgw_id,region):

    ec2_c = boto3.client('ec2', region_name = region)
    conn = sqlite3.connect(db_file)
    c = conn.cursor()

    
    # clear user terminal for better readability
    os.system('clear')

    def user_question():
        user_response = 'y'

        if user_response.lower() == 'y':
            print("\n")
            c.execute('SELECT vpc_id,vpc_cidr FROM tgw_migration')

            # Create a separate list of VPC CIDRs and Ids
            cidrs = []
            vpcs = []
            for element in c:
                vpcs.append(element[0])
                cidrs.append(element[1])

                        # Now find and update each VPC main route table
            try:
                for vpc in vpcs:
                    # Get VPC route table
                    response = ec2_c.describe_route_tables(
                        Filters=[
                            {
                                'Name':'vpc-id',
                                'Values': [vpc]
                            },
                            {
                                'Name':'association.main',
                                'Values': ['true']
                            }
                        ]
                    )

                    vpc_route_table = response['RouteTables'][0]['RouteTableId']

                    
                    print("Deleting TGW routes from %s's main route table: %s ..." % (vpc,vpc_route_table))
                    # Update the route table with routes to all other VPCs attached to TGW
                    for cidr in cidrs:
                        try:
                            ec2_c.delete_route(
                                DestinationCidrBlock=cidr,
                                RouteTableId=vpc_route_table
                            )
                        except:
                            pass
            
            except:
                raise

        elif user_response.lower() == 'n':
            print("\nSkipping route table updates...")



        else: 
            print("\nYou must choose 'Y' or 'N' the question above")
            user_question()
    
    user_question()