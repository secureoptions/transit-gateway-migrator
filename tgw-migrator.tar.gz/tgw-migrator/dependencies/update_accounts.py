import re

def update_accounts():
    accounts_file = '/home/ec2-user/tgw-migrator/dependencies/accounts.txt'
    user_response = raw_input("\nPlease choose A,B or C\n"
                                "-------------------------------------------------\n"
                                "A) Register secondary AWS accounts with this tool\n"
                                "B) De-register secondary AWS accounts\n"
                                "C) List registered accounts\n"
                                "D) Exit\n"
                                "-------------------------------------------------\n"
                                "a\\b\\c\\D> ") or "D"
    
    if user_response.lower() == 'a':
        accounts = raw_input("\nYou can add one or more 12-digit AWS accounts (separated\n"
                            "by commas)\n"
                            "--------------------------------------------------------\n"
                            "ex. 1234-5678-9012> ")

        accounts = accounts.replace('-','')
        accounts = accounts.replace(' ','')
        accounts = accounts.split(',')

        # Get existing list of accounts
        with open(accounts_file,'r') as f:
            existing_string = f.read()
        final_list = existing_string.split(',')

        # Make sure each account number is valid
        invalid_list=[]
        for acct in accounts:
            if re.match(r'[0-9]{12}',acct):
                final_list.append(acct)
            else:
                invalid_list.append(acct)
        
        if len(invalid_list) > 0:
            for acct in invalid_list:
                print acct

            print("\nThe above listed accounts are invalid and will not\n"
                        "be added to the registered accounts. Please check\n"
                        "their format and add them again.")
            final_string = ','.join(final_list)
            with open(accounts_file, 'w+') as f:
                f.write(final_string)
        else:
            final_string = ','.join(final_list)
            with open(accounts_file, 'w+') as f:
                f.write(final_string)
        update_accounts()
    
    elif user_response.lower() == 'b':
        accounts = raw_input("\nYou can add one or more 12-digit AWS accounts (separated\n"
                    "by commas)\n"
                    "--------------------------------------------------------\n"
                    "ex. 000000000000> ")
        accounts = accounts.replace('-','')
        accounts = accounts.replace(' ','')
        accounts = accounts.split(',')

        # Get existing list of accounts
        with open(accounts_file,'r') as f:
            existing_string = f.read()
        existing_list = existing_string.split(',')

        # Make sure each account number is valid
        list_to_remove = []
        invalid_list=[]
        for acct in accounts:
            if re.match(r'[0-9]{12}',acct):
                list_to_remove.append(acct)
            else:
                invalid_list.append(acct)
        
        if len(invalid_list) > 0:
            for acct in invalid_list:
                print acct

            print("\nThe above listed accounts are invalid\n"
                        "Please check their format and try again.\n")

            existing_list = [item for item in existing_list if item not in list_to_remove]
            final_string = ','.join(existing_list)
            with open(accounts_file, 'w+') as f:
                f.write(final_string)

        else:
            existing_list = [item for item in existing_list if item not in list_to_remove]
            final_string = ','.join(existing_list)
            with open(accounts_file, 'w+') as f:
                f.write(final_string)
        update_accounts()

    elif user_response.lower() == 'c':
        with open(accounts_file,'r') as f:
            existing_string = f.read()
        
        existing_list = existing_string.split(',')
        for acct in existing_list:
            print acct
        update_accounts()
    
    elif user_response.lower() == 'd':
        return
    
    else:
        print("\nPlease choose a valid option")
        update_accounts()