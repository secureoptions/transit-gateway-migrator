#! /usr/bin/python2.7
import boto3
import os
import sys
from botocore.exceptions import ClientError
from region import region
from create_tgw import create_tgw
from attach_spoke_vpcs import attach_spoke_vpcs
from list_attachments import list_attachments
from add_routes import add_routes
from detach_vpcs import detach_vpcs
from create_ram import create_ram
from delete_routes import delete_routes
from update_accounts import update_accounts

dynamodb = boto3.resource('dynamodb', region_name = region)
table = dynamodb.Table('TgwMigrationTable')

def migrator():
    def check_for_tgw():
        response = table.get_item(
            Key = {
                'VpcId' : 'vpc-xxxx'
            },
            AttributesToGet = [
                'TgwId'
            ],
            ConsistentRead=True
            )

        try:
            if response['Item']['TgwId']:
                # TGW exists. Store its Id
                tgw_id = response['Item']['TgwId']
                os.system('clear')
                print("\nA TGW (%s) has been registered in this tool" % tgw_id)
                return tgw_id

        except KeyError:
            # Create TGW and store its Id
            os.system('clear')
            print("\nThis tool does not currently have a TGW id registered with it...")
            tgw_id = create_tgw(table)
            return tgw_id

    os.system('clear')
    print("********************** TGW MIGRATOR **********************\n")
    def ask_question():
        user_response = raw_input("\nWhat would you like to do? Choose option A - I:\n"
                                    "--------------------------------------------------------\n"
                                    "A) Register Transit Gateway\n"
                                    "B) Share registered TGW with other AWS accounts\n"
                                    "C) Attach VPCs to registered TGW\n"
                                    "D) Enable routing between attached VPCs\n"
                                    "E) Disable routing between attached VPCs\n"
                                    "F) List existing VPC attachments\n"
                                    "G) Detach VPCs and deregister TGW\n"
                                    "H) Add or delete secondary AWS accounts\n"
                                    "I) Exit\n"
                                    "--------------------------------------------------------\n"
                                    "> ")                   

        if user_response.lower() == 'a':
            # User wants to create or add TGW
            tgw_id = check_for_tgw() 
            ask_question()

        if user_response.lower() == 'b':
            # User wants to share TGW with other accounts
            tgw_id = check_for_tgw()
            create_ram(table,tgw_id)
            ask_question()

        elif user_response.lower() == 'c':
            # User wants to attach VPCs. First check TGW existence
            tgw_id = check_for_tgw()
            attach_spoke_vpcs(table,tgw_id)

        elif user_response.lower() == 'd':
            # User wants to enable routing between VPCs
            tgw_id = check_for_tgw() 
            add_routes(table,tgw_id)
        
        elif user_response.lower() == 'e':
            # User wants to disable routing from VPCs and detach them from TGW
            tgw_id = check_for_tgw() 
            delete_routes(table,tgw_id)

        elif user_response.lower() == 'f':
            # List out the VPC attachments in DB
            tgw_id = check_for_tgw() 
            list_attachments(table)
            ask_question()
        
        elif user_response.lower() == 'g':
            # Deregister and delete TGW
            tgw_id = check_for_tgw() 
            detach_vpcs(table,tgw_id)
        
        elif user_response.lower() == 'h':
            # Update secondary accounts
            update_accounts()
        
        elif user_response.lower() == 'i':
            # Exit to CLI
            os.system('clear')
            print("\nBye!!\n")
            sys.exit()
        
        else:
            print("\nPlease choose a valid option")
            ask_question()

        print("\nDone !!!\n")
        ask_question()
    ask_question()