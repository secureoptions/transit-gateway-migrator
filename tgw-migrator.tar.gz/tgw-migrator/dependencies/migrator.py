#! /usr/bin/python2.7

import sqlite3
from sqlite3 import Error
import boto3
import pandas
import os
import subprocess
import sys
import fnmatch
import time
import threading
import re
from region import region
from polltaggedvpcs import polltaggedvpcs
from pollspokevpcs import pollspokevpcs
from deletetgw import deletetgw
from addroutes import addroutes
from deleteroutes import deleteroutes

ec2_c = boto3.client('ec2', region_name = region)

def migrator():
	os.system('clear')
	print("********************** TGW MIGRATOR **********************\n")
	user_response = raw_input("What would you like to do? Choose A, B, C, D, E or F:\n"
						"A) Attach VPCs to TGW\n"
						"B) Enable routing between attached VPCs\n"
						"C) Disable routing between VPCs and detach VPCs from TGW\n"
						"D) ONLY disable routing between attached VPCs\n"
						"E) List existing VPC attachments\n"
						"F) Exit\n"
						"------------------------------------------\n"
						"> ")
	print ("\n")
	db_file=''
	for file in os.listdir('/home/ec2-user/tgw-migrator/dependencies/'):
		if fnmatch.fnmatch(file, '*.db'):
			db_file = os.path.join('/home/ec2-user/tgw-migrator/dependencies/', file)
			tgw_id = file.split('.')[0]

	# Make a fancy spinning cursor while waiting waiting on the following TGW to become available (yes, I'm bored...)
	def spin_cursor():
		while True:
			for cursor in '|/-\\':
				sys.stdout.write(cursor)
				sys.stdout.flush()
				time.sleep(0.1) # adjust this to change the speed
				sys.stdout.write('\b')
				if done:
					return

	spin_thread = threading.Thread(target=spin_cursor)

	try: 
		if user_response.lower() == "a" :

			if db_file == '':
				try:  
					response = ec2_c.create_transit_gateway()
					tgw_id = response['TransitGateway']['TransitGatewayId']
					print("Created new TGW, %s ..." % tgw_id)

					print("Creating new DB to store state of TGW, VPCs, route tables and routes...")
					db_file = '/home/ec2-user/tgw-migrator/dependencies/' + tgw_id + '.db'
					conn = sqlite3.connect(db_file)

					print("Creating DB table...")
					c = conn.cursor()
					c.execute('''CREATE TABLE tgw_migration (vpc_id, vpc_cidr, vpc_attachment)''')
				

				except:
					raise

			#try:
			# the following logging says it all
			print("TGW and DB healthy, continuing...")

			print("Waiting for %s to become available before continuing..." % tgw_id)
			# start the spinner in a separate thread
			done = False
			spin_thread.start()

			# check that TGW is in an available state before continuing. Wait 5 minutes for it to transition to 'available' and then timeout with error
			count = 0
			while True:
				response = ec2_c.describe_transit_gateways(
					TransitGatewayIds=[tgw_id]
				)
				if response['TransitGateways'][0]['State'] == 'available':
					break
				else:
					if count >= 300:
						raise Exception("%s took longer than 5 minutes to go into available state. Stopping migration..." % tgw_id)
					else:
						time.sleep(5)
						count +=5

			# stop the spinner before moving on
			done = True
			spin_thread.join()
			
			pollspokevpcs(db_file,tgw_id,region)
			polltaggedvpcs(db_file,tgw_id,region)

		elif user_response.lower() == 'b':
			addroutes(db_file,tgw_id,region)


		elif user_response.lower() == 'c':
			if db_file == '':
				print("There is nothing to rollback...exiting")
			else:
				print("Rolling back attachments to %s..." % tgw_id)
				deletetgw(db_file,tgw_id,region)
		
		elif user_response.lower() == 'd':
			deleteroutes(db_file,tgw_id,region)
		
		elif user_response.lower() == 'e':
			try:
				conn = sqlite3.connect(db_file)
				c = conn.cursor()
				print pandas.read_sql_query("SELECT * FROM tgw_migration", conn)
			except:
				print("There are no attachments that the migrator created...")
		
		elif user_response.lower() == 'f':
			sys.exit()
		
		else:
			print('\nERROR: You must choose a valid option')
			sys.exit()
		
		print("\nDone!!\n")

	except:
		raise





