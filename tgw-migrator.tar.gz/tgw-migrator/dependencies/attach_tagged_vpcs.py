import boto3
import sqlite3
import sys
import time
import threading
from region import region

def attach_tagged_vpcs(ec2_c,ec2_r,cgw,aws_id,table,tgw_id,vpc_attachments):
    filters = [{'Name':'tag:attach-tgw', 'Values':['true','True','TRUE']}]
    vpcs = ec2_r.vpcs.filter(Filters=filters)
    for vpc in vpcs:
        try:
            response = ec2_c.describe_vpcs(
                VpcIds=[vpc.id]
            )
            vpc_cidr_block = response['Vpcs'][0]['CidrBlock']

            # Make sure there is a subnet in each AZ for this region, then pick the first three subnets to use in the attachment
            response = ec2_c.describe_availability_zones()
            zones = []
            for zone in response['AvailabilityZones']:
                zones.append(zone['ZoneName'])

            subnets = ec2_r.subnets.filter(Filters=[{'Name':'vpc-id','Values': [vpc.id]}])
            subnets_ids = []
            for subnet in subnets:
                subnets_ids.append(subnet.id)

            subnets_info = ec2_c.describe_subnets(
                    SubnetIds=subnets_ids
            )

            subnets_to_attach = []
            for zone in zones:
                for subnet in subnets_info['Subnets']:
                    if subnet['AvailabilityZone'] == zone:
                        subnets_to_attach.append(subnet['SubnetId'])
                        break
            
            # Compare number of AZs to the number of subnets; they should be equal. If not rollback
            if len(zones) == len(subnets_to_attach):
                response = ec2_c.create_transit_gateway_vpc_attachment(
                        TransitGatewayId=tgw_id,
                        VpcId=vpc.id,
                        SubnetIds=subnets_to_attach
                )
                vpc_attachment_id = response['TransitGatewayVpcAttachment']['TransitGatewayAttachmentId']
                print("attached %s to %s. Adding to DB..." % (vpc.id,tgw_id))


                table.put_item(
                    Item={
                        'VpcId' : vpc.id,
                        'VpcAttachmentId' : vpc_attachment_id,
                        'VpcCidr' : vpc_cidr_block,
                        'OwnerAccount' : aws_id,
                        'Source' : 'tagged'
                    })
                vpc_attachments[vpc_attachment_id] = aws_id
                
            else:
                response = raw_input("\nBest practices suggest that a VPC has one subnet\n"
                                        "per Availability Zone when attaching to a TGW. However\n"
                                        "%s does not have at least one subnet in each\n"
                                        "AZ. Do you want the tool to ignore this VPC or proceed\n"
                                        "in attaching it? Choose 'A' or 'B'\n"
                                        "----------------------------------------------------------\n"
                                        "A) Proceed with attaching the VPC to the TGW\n"
                                        "B) Skip this VPC\n"
                                        "----------------------------------------------------------\n"
                                        "a\\B> " % vpc.id) or "B"
                if response.lower() == 'a':
                    print("\n")
                    response = ec2_c.create_transit_gateway_vpc_attachment(
                        TransitGatewayId=tgw_id,
                        VpcId=vpc.id,
                        SubnetIds=subnets_to_attach
                )
                    vpc_attachment_id = response['TransitGatewayVpcAttachment']['TransitGatewayAttachmentId']
                    print("attached %s to %s. Adding to DB..." % (vpc.id,tgw_id))


                    table.put_item(
                        Item={
                            'VpcId' : vpc.id,
                            'VpcAttachmentId' : vpc_attachment_id,
                            'VpcCidr' : vpc_cidr_block,
                            'OwnerAccount' : aws_id,
                            'Source' : 'tagged'
                        })
                    vpc_attachments[vpc_attachment_id] = aws_id
                else:
                    print('Skipping %s...' % vpc.id)
                    pass
        except:
            pass
        
    return vpc_attachments