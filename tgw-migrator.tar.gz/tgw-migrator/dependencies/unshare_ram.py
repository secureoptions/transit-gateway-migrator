import boto3
from region import region

def unshare_ram(tb):
    table = tb
    ram = boto3.client('ram', region_name = region)
    # see if there is a registered RAM share
    try:
        response = table.get_item(
            Key = {
                'VpcId' : 'vpc-xxxx'
            },
            AttributesToGet = [
                'RamShareArn'
            ],
            ConsistentRead=True
        )

        if response['Item']['RamShareArn']:
            share_arn = response['Item']['RamShareArn']

            ram.delete_resource_share(
                resourceShareArn=share_arn
            )
    except KeyError:
        pass
