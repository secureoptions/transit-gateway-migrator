import decimal
import json

def retrieve_items(tb):
    # Helper class to convert a DynamoDb item to Json
    class DecimalEncoder(json.JSONEncoder):
        def default(self, o):
            if isinstance(o, decimal.Decimal):
                if o % 1 > 0:
                    return float(o)
                else:
                    return int(o)
            return super(DecimalEncoder, self).default(o)

    table = tb
    # Retrieve all items in DB table
    response = table.scan()

    # Create pretty table for user based off the items in the DB
    items_dict = {}
    for i in response['Items']:
        # get all the table entries in json format
        json_str = json.dumps(i, cls=DecimalEncoder)
        #using json.loads will turn your data into a python dictionary
        response_dict = json.loads(json_str)

        if response_dict.get('VpcAttachmentId') != None:
            # Create a dictionary of each item for easy retrieval
            items_dict[response_dict.get('VpcId')] = {'VpcAttachmentId' : response_dict.get('VpcAttachmentId'), 'VpcCidr' : response_dict.get('VpcCidr'), 'OwnerAccount' : response_dict.get('OwnerAccount')}

    return items_dict