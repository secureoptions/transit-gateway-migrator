import boto3
import sys
import time
import os
import threading
from botocore.exceptions import ClientError
from region import region
from update_accounts import update_accounts

def create_ram(tb,tgw_id):

    user_answer = raw_input("\nDo you need to register/deregister any AWS accounts\n"
                              "with this tool before sharing the TGW?\n"
                              "---------------------------------------------------\n"
                              "n\\Y> ") or "y"

    if user_answer.lower() == 'y':
        update_accounts()

    ram = boto3.client('ram',region_name = region)
    # Check if there are any secondary AWS accounts with spoke VPCs that need to be attached
    with open('dependencies/accounts.txt','r') as f:
        accounts = f.read()
    accounts = accounts.replace('-','').replace(' ','').replace('\n','')
    accounts = accounts.split(',')
    if accounts[0] == '':
        del accounts[0]

    print("\n")
    if len(accounts) == 0:
        # There are no secondary accounts. Skip
        print("\nThere are no secondary accounts to share the TGW with...")
        return
    else:
        table = tb
        response = table.get_item(
            Key = {
                'VpcId' : 'vpc-xxxx'
            },
            AttributesToGet = [
                'TgwArn'
            ],
            ConsistentRead=True
            )

        tgw_arn = response['Item']['TgwArn']

        try:
            response = table.get_item(
                Key = {
                    'VpcId' : 'vpc-xxxx'
                },
                AttributesToGet = [
                    'RamShareArn'
                ],
                ConsistentRead=True
            )

            if response['Item']['RamShareArn']:
                print("\n%s has been shared with secondary accounts..." % tgw_id)
                share_arn = response['Item']['RamShareArn']
        except:
            try:
                response = ram.create_resource_share(
                    name='TgwMigratorShare',
                    resourceArns=[tgw_arn],
                    principals=accounts
                )
                share_arn = response['resourceShare']['resourceShareArn']

                
                table.put_item(
                    Item={
                        'VpcId' : 'vpc-xxxx',
                        'TgwId' : tgw_id,
                        'TgwArn': tgw_arn,
                        'RamShareArn' : share_arn
                          })
            except ClientError as e:
                if e.response['Error']['Code'] == 'InvalidParameterException':
                    # There are no secondary accounts. Skip
                    print("\nUnable to create resource share with secondary accounts")
                    return

                              
            count = 15
            for i in range(15,1,-1):
                os.system('clear')
                print("\nwaiting %s seconds for share to propagate secondary accounts" % count)
                time.sleep(1)
                count = count - 1
        # Now that the RAM share has been created for all secondary accounts, poll for successful assume role and share
        sts = boto3.client('sts', region_name = region)
        this_acct = sts.get_caller_identity()
        this_acct = this_acct['Account']
        os.system('clear')
        print("%s has been shared with secondary accounts through RAM...\n"
              "Please launch the 'secondary-acct' Cloudformation stack in each of your secondary\n"
              "AWS accounts at this time. Specify the AWS account id that is running this tool\n"
              "when the the stack ask you for it (it asks for 'Parent acct'). The secondary-acct\n"
              "Cloudformation stack will create the necessary IAM role granting this tool permission\n"
              "to migrate VPCs to the TGW on behalf of the secondary account. This tool will be\n"
              "constantly checking to see if IAM roles were successfully deployed and will notify you\n"
              "of this below.\n"
              "--------------------------------------------------------------------------\n" % (tgw_id))
        def spin_cursor():
            while True:
                    # Make a fancy spinning cursor while waiting waiting on the following TGW to become available (yes, I'm bored...)
                for cursor in '|/-\\':
                    sys.stdout.write(cursor)
                    sys.stdout.flush()
                    time.sleep(0.1) # adjust this to change the speed
                    sys.stdout.write('\b')
                    if done:
                        return
        spin_thread = threading.Thread(target=spin_cursor)
        done = False
        num_accts = len(accounts)

        print("\nChecking for the successful 'secondary-acct' Cloudformation stack\n"
            "deployments in secondary accounts...you need to deploy it in %s registered\n"
            "accounts" % num_accts)
        spin_thread.start()


        while True:
            try:
                for acct in accounts:
                    try:
                        creds = sts.assume_role(
                            RoleArn='arn:aws:iam::' + acct + ':role/TgwMigratorCrossAccountAccess',
                            RoleSessionName='TgwMigrator'
                        )             
                        # Use the retrieved creds above to make API calls
                        ram = boto3.client('ram',
                            region_name=region,
                            aws_access_key_id = creds['Credentials']['AccessKeyId'],
                            aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                            aws_session_token = creds['Credentials']['SessionToken']
                            )

                        share_invite_arn = ram.get_resource_share_invitations(
                            resourceShareArns=[
                                share_arn
                            ]
                        )
                        share_invite_arn = share_invite_arn['resourceShareInvitations'][0]['resourceShareInvitationArn']


                        # Accept the TGW share from the secondary account
                        ram.accept_resource_share_invitation(
                            resourceShareInvitationArn=share_invite_arn
                        )
                        # Remove this account from list so we don't check it again
                        accounts.remove(acct)
                        print("\naccount %s has successfully deployed the 'secondary-acct'\n"
                            "Cloudformation stack!!\n"
                            "There are %s more accounts that need it...checking status" % (acct,str(len(accounts))))
                        break
                                
                    except ClientError as e:
                        if e.response['Error']['Code'] == 'AccessDenied':
                            time.sleep(5)
                            pass
                        elif e.response['Error']['Code'] == 'ResourceShareInvitationAlreadyAcceptedException':
                            accounts.remove(acct)
                            pass

                if len(accounts) == 0:
                        break
            # The following exception is caught if user wants to stop the polling with ctrl-c
            except KeyboardInterrupt:
                done = True
                spin_thread.join()
                sys.exit()

        done = True
        spin_thread.join()
        os.system('clear')
        print("\nSuccess!!! All secondary accounts are ready for deployment!\n"
            "You can now attach VPCs and enable routing with this tool!")