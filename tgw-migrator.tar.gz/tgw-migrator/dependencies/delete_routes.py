import boto3
import os
from region import region
from retrieve_items import retrieve_items


def delete_routes(tb,tgw_id):
    table = tb

    def del_routes(c,acct):
        ec2_c = c
        user_response = 'y'

        if user_response.lower() == 'y':
            # Get dictionary of all items in DB
            items = retrieve_items(table)
            
            # Create a separate list of VPC CIDRs and Ids
            cidrs = []
            vpcs = []
            for item in items:
                    cidrs.append(items[item]['VpcCidr'])
                    if items[item]['OwnerAccount'] == acct:
                        vpcs.append(item)

                        # Now find and update each VPC main route table
            try:
                for vpc in vpcs:
                    # Get VPC route table
                    response = ec2_c.describe_route_tables(
                        Filters=[
                            {
                                'Name':'vpc-id',
                                'Values': [vpc]
                            },
                            {
                                'Name':'association.main',
                                'Values': ['true']
                            }
                        ]
                    )

                    vpc_route_table = response['RouteTables'][0]['RouteTableId']

                    
                    print("Deleting TGW routes from %s's main route table:\n"
                          "%s ..." % (vpc,vpc_route_table))
                    # Update the route table with routes to all other VPCs attached to TGW
                    for cidr in cidrs:
                        try:
                            ec2_c.delete_route(
                                DestinationCidrBlock=cidr,
                                RouteTableId=vpc_route_table
                            )
                        except:
                            pass
            
            except:
                raise

        elif user_response.lower() == 'n':
            print("\nSkipping route table updates...")



        else: 
            print("\nYou must choose 'Y' or 'N' the question above")
            del_routes(c,acct)
    
    # First delete TGW routes in this account
    print("\nDeleting TGW routes in VPCs of parent account")
    ec2_c = boto3.client('ec2', region_name = region)
    del_routes(ec2_c,'parent account')

    # Delete TGW routes in any secondary accounts
    with open('dependencies/accounts.txt','r') as f:
        accounts = f.read()
        accounts = accounts.replace('-','').replace(' ','').replace('\n','')
        accounts = accounts.split(',')
        
    print("\n")
    if accounts[0] == '' and len(accounts) < 2:
        # There are no secondary accounts. Skip
        return
    else:
        for account in accounts:
            if account != '':
                # Assume role for secondary account
                sts = boto3.client('sts',region_name=region)
                creds = sts.assume_role(
                    RoleArn='arn:aws:iam::' + account + ':role/TgwMigratorCrossAccountAccess',
                    RoleSessionName='TgwMigratorUpdateDb'
                )

                # Use the retrieved creds above to make API calls
                ec2_c = boto3.client('ec2',
                        region_name = region,
                        aws_access_key_id = creds['Credentials']['AccessKeyId'],
                        aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                        aws_session_token = creds['Credentials']['SessionToken']
                        )

                print("\nDeleting TGW routes in VPCs in account %s" % account)
                del_routes(ec2_c,account)