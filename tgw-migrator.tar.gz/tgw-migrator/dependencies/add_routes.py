import boto3
import os
from region import region
from list_attachments import list_attachments
from retrieve_items import retrieve_items

def add_routes(tb, tgw_id):
    table = tb

    # clear user terminal for better readability
    os.system('clear')

    # List attachments from DB for user to see
    list_attachments(table)

    def enable_routing(ec2_c, account):

        # Get dictionary of all items in DB
        items = retrieve_items(table)
        
        # Create a separate list of VPC CIDRs and Ids
        cidrs = []
        vpcs = []
        for item in items:
            cidrs.append(items[item]['VpcCidr'])

            if items[item]['OwnerAccount'] == account:
                vpcs.append(item)
        
        # Now find and update each VPC main route table
        try:
            for vpc in vpcs:
                # Get VPC route table
                response = ec2_c.describe_route_tables(
                    Filters=[
                        {
                            'Name':'vpc-id',
                            'Values': [vpc]
                        },
                        {
                            'Name':'association.main',
                            'Values': ['true']
                        }
                    ]
                )

                vpc_route_table = response['RouteTables'][0]['RouteTableId']


                print("Adding TGW routes to %s's main route table:\n"
                        "%s ...\n" % (vpc,vpc_route_table))
                # Update the route table with routes to all other VPCs attached to TGW
                for cidr in cidrs:
                    try:
                        ec2_c.create_route(
                            DestinationCidrBlock=cidr,
                            TransitGatewayId=tgw_id,
                            RouteTableId=vpc_route_table
                        )
                    except:
                        pass
        
        except:
            raise

    def user_question():
        user_response = raw_input("\n\nThe TGW migrator will attempt to update each of the above VPCs' main route\n"
                                      "table with routes to all the other attached VPCs. Note that if two or more\n"
                                      "VPCs have the same network CIDR, one of their routes will not be propagated\n"
                                      "through the TGW. Do you still want to continue?\n"
                                      "---------------------------------------------------------------------------\n"
                                "y\\N > ") or "N"

        if user_response.lower() == 'y':
            print("\n")
            print("Enabling routing for VPCs in parent account...")
            # First enabling routing between VPCs in this account
            ec2_c = boto3.client('ec2', region_name = region)
            enable_routing(ec2_c,'parent account')

            # See if there are any secondary accounts that need to be updated as well
            with open('dependencies/accounts.txt','r') as f:
                accounts = f.read()
            accounts = accounts.replace('-','').replace(' ','').replace('\n','')
            accounts = accounts.split(',')
        
            if accounts[0] == '' and len(accounts) < 2:
                # There are no secondary accounts. Skip
                return
            else:
                for account in accounts:
                    if account != '':
                        try:
                            # Assume role for secondary account
                            sts = boto3.client('sts',region_name=region)
                            creds = sts.assume_role(
                                RoleArn='arn:aws:iam::' + account + ':role/TgwMigratorCrossAccountAccess',
                                RoleSessionName='TgwMigratorUpdateDb'
                            )

                            # Use the retrieved creds above to make API calls
                            ec2_c = boto3.client('ec2',
                                    region_name = region,
                                    aws_access_key_id = creds['Credentials']['AccessKeyId'],
                                    aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                                    aws_session_token = creds['Credentials']['SessionToken']
                                    )
                            print("\nEnabling routing for VPCs in account %s" % account)
                            enable_routing(ec2_c,account)
                        except:
                            print("There was an issue with accessing %s. Please check its permissions")


        elif user_response.lower() == 'n':
            print("\nSkipping route table updates...")



        else: 
            print("\nYou must choose 'Y' or 'N' the question above")
            user_question()
    
    user_question()