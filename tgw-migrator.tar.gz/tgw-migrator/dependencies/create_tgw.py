#! /usr/bin/python2.7

import boto3
import sys
import time
import re
import threading
from region import region

ec2 = boto3.client('ec2', region_name = region)
sts = boto3.client('sts', region_name = region)

def create_tgw(tb):
    table = tb
    def ask_question():
        user_response = raw_input("\nDo you want to add an existing TGW id to this tool for the migration, or\n"
                                    "have the tool create a new TGW? Choose A, B or C:\n"
                                    "------------------------------------------------------------------------\n"
                                    "A) Create a new TGW\n"
                                    "B) Add an existing TGW id to this tool\n"
                                    "C) Exit\n"
                                    "------------------------------------------------------------------------\n"
                                    "> ")

        if user_response.lower() == 'a':
            # Make a fancy spinning cursor while waiting waiting on the following TGW to become available (yes, I'm bored...)
            def spin_cursor():
                while True:
                    for cursor in '|/-\\':
                        sys.stdout.write(cursor)
                        sys.stdout.flush()
                        time.sleep(0.1) # adjust this to change the speed
                        sys.stdout.write('\b')
                        if done:
                            return
                            
            spin_thread = threading.Thread(target=spin_cursor)

            try: 
                # Create Transit Gateway
                response = ec2.create_transit_gateway(
                    Options={
                        'AutoAcceptSharedAttachments':'enable'
                    }
                )
                tgw_id = response['TransitGateway']['TransitGatewayId']
                print("\nCreated new TGW, %s ..." % tgw_id)
                
                table.put_item(
                    Item={
                        'VpcId' : 'vpc-xxxx',
                        'TgwId' : tgw_id,
                        'TgwArn': response['TransitGateway']['TransitGatewayArn']
                    }
                                )


                print("Waiting for %s to become available before continuing..." % tgw_id)
                # start the spinner cursor in a separate thread
                done = False
                spin_thread.start()

                # check that TGW is in an available state before continuing. Wait 5 minutes for it to transition to 'available' and then timeout with error
                count = 0
                while True:
                    response = ec2.describe_transit_gateways(
                        TransitGatewayIds=[tgw_id]
                    )
                    if response['TransitGateways'][0]['State'] == 'available':
                        break
                    else:
                        if count >= 300:
                            raise Exception("\n%s took longer than 5 minutes to go into available state.\n"
                                            "Please check on its state manually\n" % tgw_id)
                        else:
                            time.sleep(5)
                            count +=5

                # stop the spinner before moving on
                done = True
                spin_thread.join()
                print("\nRegistering %s with the DB...\n"
                        "Done !!" % tgw_id)
                return tgw_id

            except:
                raise
        
        elif user_response.lower() == 'b':
            def get_tgw_id():
                tgw_id = raw_input("\nPlease provide the Transit Gateway Id that you would like the\n"
                                    "tool use for the migration (note: the Transit Gateway must belong\n"
                                    "to the account this tool is running in and it must have the 'Auto\n"
                                    "accept shared attachments' enabled).\n"
                                    "-----------------------------------------------------------------\n"
                                    "> ")
                m = re.match('tgw-.*',tgw_id)

                if m:
                    try: 
                        response =ec2.describe_transit_gateways(
                            TransitGatewayIds=[tgw_id]
                            )
                        if response['TransitGateways'][0]['State'] == 'available':
                            table.put_item(
                                Item={
                                    'VpcId' : 'vpc-xxxx',
                                    'TgwId' : tgw_id,
                                    'TgwArn' : response['TransitGateways'][0]['TransitGatewayArn']
                                }
                                            )
                            print("\nRegistering %s with the DB...\n"
                                    "Done!!" % tgw_id)
                            return tgw_id
                        elif response['TransitGateways'][0]['Options']['AutoAcceptSharedAttachments'] == 'disable':
                            print('\nTGW must have \'AutoAcceptSharedAttachments\' enabled. Please check\n'
                                    'this setting on the TGW and try again')
                            get_tgw_id()
                        else:
                            print('\nTGW is not in an available state...try again')
                            get_tgw_id()
                    except:
                        response  = sts.get_caller_identity()
                        print('\nIt does not appear that this TGW exists in this account (AWS Acct: %s\n'
                            'Please try again' % response['Account'])
                        get_tgw_id()

                else:
                    print("\nInvalid TGW id. Please provide a TGW id in the form of 'tgw-xxxxxxxx'")
                    get_tgw_id()
            get_tgw_id()
        elif user_response.lower() == 'c':
                sys.exit()
        
        else:
            print('\nPlease choose a valid option')
            ask_question()
    
    ask_question()
