import boto3
import sqlite3
import glob
import time
import sys
import threading
import os
from region import region
from deleteroutes import deleteroutes


def deletetgw(db_file,tgw_id,region):

    deleteroutes(db_file,tgw_id,region)

    ec2_c = boto3.client('ec2', region_name = region)
    conn = sqlite3.connect(db_file)
    c = conn.cursor()

    # Get a list of VPC attachments to the TGW that need to be detached
    c.execute('SELECT vpc_attachment,vpc_id FROM tgw_migration')
    
    try:
        for attach in c:
            response = ec2_c.describe_transit_gateway_vpc_attachments(
                TransitGatewayAttachmentIds=[attach[0]]
            )
            if response['TransitGatewayVpcAttachments'][0]['State'] == "pending":
                print("%s is still in 'pending' state. Attachments must be in 'available' state before they can be deleted...EXITING!" % attach[0])
                sys.exit()

            print("Detaching %s (%s) from %s...." % (attach[0],attach[1],tgw_id))
            ec2_c.delete_transit_gateway_vpc_attachment(
                TransitGatewayAttachmentId=attach[0]
            )
    except:
        print("ERROR: Cannot delete %s (%s) from %s...skipping this attachment" % (attach[0],attach[1],tgw_id))
        pass

    try:
        c.execute('SELECT vpc_attachment FROM tgw_migration')
        vpc_attachment = c.fetchall()
        for attach in vpc_attachment:
            time.sleep(1)

            print("Waiting on %s to fully delete..." % attach[0])
            count = 0
            while True:
                response = ec2_c.describe_transit_gateway_vpc_attachments(
                    TransitGatewayAttachmentIds=[attach[0]]
                )
                if response['TransitGatewayVpcAttachments'][0]['State'] == "deleted":
                    c.execute('DELETE FROM tgw_migration WHERE vpc_attachment LIKE ?', ('%'+attach[0]+'%',))
                    break
                else:
                    if count >= 300:
                        print("%s is still \"Deleting\" after 5 minutes. You may want to manually check on this attachment. Skipping it..." % attach[0])
                        break
                    else:
                        time.sleep(5)
                        count += 5   
    
        conn.commit()
        conn.close()
    except:
        raise
    
    second_user_response = raw_input("\n\nAttachments have been deleted. Do you want to delete the\n"
                            "TGW that was created by this migrator as well?\n"
                            "--------------------------------------------------\n"
                            "n\\Y > ") or "y"
                   
        
    if second_user_response.lower() == 'y':
        try:
            print("deleting %s..." % tgw_id)
            ec2_c.delete_transit_gateway(
                TransitGatewayId=tgw_id
            )
            os.remove('/home/ec2-user/tgw-migrator/dependencies/' + tgw_id + '.db')
        except:
            print("\n\nHmm...%s was unable to be deleted. You may try to delete this\n"
                    "connection manually")
            raise
    else:
        pass
                