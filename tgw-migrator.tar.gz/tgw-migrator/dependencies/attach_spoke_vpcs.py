import boto3
import sys
import time
import os
import re
import threading
from region import region
from attach_tagged_vpcs import attach_tagged_vpcs
from create_ram import create_ram

vpc_attachments = {}
def attach_spoke_vpcs(table,tgw_id):

    def attach_vpcs(ec2_c,ec2_r,cgw,aws_id,table,tgw_id):
        try:
            # Describe CGWs matching IP customer provided
            response = ec2_c.describe_customer_gateways(
                Filters = [{
                    'Name':'ip-address',
                    'Values':[cgw]
                    }]
                )

            # Find VPNs associated with CGW id
            response = ec2_c.describe_vpn_connections(
                Filters = [{
                    'Name':'customer-gateway-id',
                    'Values':[response['CustomerGateways'][0]['CustomerGatewayId']]
                    }]
                )

            # For each VPN returned describe its VGW id and append to a list
            vgws = []
            for vpn in response['VpnConnections']:
                vgws.append(vpn['VpnGatewayId'])

            # For each VGW in the list, describe it so we can find out if/what VPC is attached
            response = ec2_c.describe_vpn_gateways(
                Filters = [{
                    'Name':'vpn-gateway-id',
                    'Values':vgws
                    }]
                )

            if len(response['VpnGateways']) >= 1:
                print("\n")
            # See if there is already a VPC attachment registered for each spoke VPC. Create one for each VPC if they are missing
            for vgw in response['VpnGateways']:
                vpc_id = vgw['VpcAttachments'][0]['VpcId']
                response = table.get_item(
                    Key = {
                        'VpcId' : vpc_id
                    },
                    AttributesToGet = [
                        'VpcId'
                    ],
                    ConsistentRead=True
                    )
                try:
                    response['Item']['VpcId']
                except KeyError:
                    try:
                        response = ec2_c.describe_vpcs(
                            VpcIds = [vpc_id]
                            )
                        vpc_cidr_block = response['Vpcs'][0]['CidrBlock']

                        # Make sure there is a subnet in each AZ for this region, then pick the first three subnets to use in the attachment
                        response = ec2_c.describe_availability_zones()
                        zones = []
                        for zone in response['AvailabilityZones']:
                            zones.append(zone['ZoneName'])

                        subnets = ec2_r.subnets.filter(Filters=[{'Name':'vpc-id','Values': [vpc_id]}])
                        subnets_ids = []
                        for subnet in subnets:
                            subnets_ids.append(subnet.id)

                        subnets_info = ec2_c.describe_subnets(
                                SubnetIds=subnets_ids
                        )

                        subnets_to_attach = []
                        for zone in zones:
                            for subnet in subnets_info['Subnets']:
                                if subnet['AvailabilityZone'] == zone:
                                    subnets_to_attach.append(subnet['SubnetId'])
                                    break
                        
                        # Compare number of AZs to the number of subnets; they should be equal. If not rollback
                        if len(zones) == len(subnets_to_attach):
                            response = ec2_c.create_transit_gateway_vpc_attachment(
                                    TransitGatewayId=tgw_id,
                                    VpcId=vpc_id,
                                    SubnetIds=subnets_to_attach
                            )

                            vpc_attachment_id = response['TransitGatewayVpcAttachment']['TransitGatewayAttachmentId']
                            print("attached %s to %s. Registering in DB..." % (vpc_id,tgw_id))

                            # Add VPC attachment to DB
                            table.put_item(
                                Item={
                                    'VpcId' : vpc_id,
                                    'VpcAttachmentId' : vpc_attachment_id,
                                    'VpcCidr' : vpc_cidr_block,
                                    'OwnerAccount' : aws_id,
                                    'Source' : 'transit-vpc'
                                })
                            
                            vpc_attachments[vpc_attachment_id] = aws_id

                        else:
                            response = raw_input("\nBest practices suggest that a VPC has one subnet\n"
                                         "per Availability Zone when attaching to a TGW. However\n"
                                         "%s does not have at least one subnet in each\n"
                                         "AZ. Do you want the tool to ignore this VPC or proceed\n"
                                         "in attaching it? Choose 'A' or 'B'\n"
                                         "----------------------------------------------------------\n"
                                         "A) Proceed with attaching the VPC to the TGW\n"
                                         "B) Skip this VPC\n"
                                         "----------------------------------------------------------\n"
                                         "a\\B> " % vpc_id) or "B"

                            if response.lower() == 'a':
                                print("\n")
                                response = ec2_c.create_transit_gateway_vpc_attachment(
                                        TransitGatewayId=tgw_id,
                                        VpcId=vpc_id,
                                        SubnetIds=subnets_to_attach
                                )

                                vpc_attachment_id = response['TransitGatewayVpcAttachment']['TransitGatewayAttachmentId']
                                print("attached %s to %s. Registering in DB..." % (vpc_id,tgw_id))

                                # Add VPC attachment to DB
                                table.put_item(
                                    Item={
                                        'VpcId' : vpc_id,
                                        'VpcAttachmentId' : vpc_attachment_id,
                                        'VpcCidr' : vpc_cidr_block,
                                        'OwnerAccount' : aws_id,
                                        'Source' : 'transit-vpc'
                                    })
                                
                                vpc_attachments[vpc_attachment_id] = aws_id
                            else:
                                print('Skipping %s...' % vpc_id)
                                pass
                    
                    except:
                        raise

        except:
            raise               

    def check_status(ec2_c,ec2_r,cgw,account,table,tgw_id):
            if len(vpc_attachments) >= 1:
                print("\nChecking status of attachments in %s" % account)
                print("waiting for all VPC attachments to go from 'pending' to 'available'...")
                def spin_cursor():
                    while True:
                            # Make a fancy spinning cursor while waiting waiting on the following TGW to become available (yes, I'm bored...)
                        for cursor in '|/-\\':
                            sys.stdout.write(cursor)
                            sys.stdout.flush()
                            time.sleep(0.1) # adjust this to change the speed
                            sys.stdout.write('\b')
                            if done:
                                return
                spin_thread = threading.Thread(target=spin_cursor)
                done = False
                spin_thread.start()
                for attach in vpc_attachments:
                    if vpc_attachments[attach] == account:
                        count = 0            
                        while True:
                            response = ec2_c.describe_transit_gateway_vpc_attachments(
                                        TransitGatewayAttachmentIds=[attach]
                            )
                            if response['TransitGatewayVpcAttachments'][0]['State'] == 'available':
                                break
                            else:
                                if count >= 300:
                                    print("\n%s is still \"Pending\" after 5 minutes.\n"
                                        "You may want to manually check on this attachment." % attach)
                                    done = True
                                    spin_thread.join()
                                    break
                                else:
                                    time.sleep(5)
                                    count += 5
                done = True
                spin_thread.join()




    # clear user terminal for better readability
    os.system('clear')
    user_response = raw_input("\nDo you want to migrate 'spoke' VPCs from a transit-VPC solution to TGW?\n"
                                "-----------------------------------------------------------------------\n"
                              "y\\N > ") or "N"
    
    if user_response.lower() == 'y':
        def get_answer():
            user_response = raw_input("\nPlease provide the public IP of ONE of your transit-VPC hub routers\n"
                                       "(If you are running redundant routers, you can choose either one.\n" 
                                       "The public IP should be in the format: 1.2.3.4)\n"
                                       "--------------------------------------------------------------------\n"
                                       "> ")
            m = re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}.\d{1,3}$', user_response)
            if m:
                cgw = str(m.group(0))
                return cgw
            else:
                print("\nYou must provide a valid IP in the form of 'x.x.x.x'")
                get_answer()
        
        
        cgw = get_answer()
        
        # Check if there are any secondary AWS accounts with spoke VPCs that need to be attached
        with open('dependencies/accounts.txt','r') as f:
            accounts = f.read()
        accounts = accounts.replace('-','').replace(' ','').replace('\n','')
        accounts = accounts.split(',')

        def get_account_creds(account):
            # Assume role for secondary account
            sts = boto3.client('sts',region_name=region)
            creds = sts.assume_role(
                RoleArn='arn:aws:iam::' + account + ':role/TgwMigratorCrossAccountAccess',
                RoleSessionName='TgwMigratorUpdateDb'
            )

            # Use the retrieved creds above to make API calls
            ec2_c = boto3.client('ec2',
                    region_name = region,
                    aws_access_key_id = creds['Credentials']['AccessKeyId'],
                    aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                    aws_session_token = creds['Credentials']['SessionToken']
                    )
            ec2_r = boto3.resource('ec2',
                    region_name = region,
                    aws_access_key_id = creds['Credentials']['AccessKeyId'],
                    aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                    aws_session_token = creds['Credentials']['SessionToken']
                    )
            return ec2_c, ec2_r
        
        if accounts[0] == '' and len(accounts) < 2:
            # There are no secondary accounts.
            # Attach VPCs in parent account
            print("\nAttaching VPCs in %s" % 'parent account')
            ec2_c = boto3.client('ec2', region_name = region)
            ec2_r = boto3.resource('ec2', region_name = region)
            vpc_attachments.update(attach_tagged_vpcs(ec2_c,ec2_r,cgw,'parent account',table,tgw_id,vpc_attachments))
            attach_vpcs(ec2_c,ec2_r,cgw,'parent account',table,tgw_id)

            # Check status of VPCs in parent account
            ec2_c = boto3.client('ec2', region_name = region)
            ec2_r = boto3.resource('ec2', region_name = region)
            check_status(ec2_c,ec2_r,cgw,'parent account',table,tgw_id)
            
        else:
            try:
                response = table.get_item(
                    Key = {
                        'VpcId' : 'vpc-xxxx'
                    },
                    AttributesToGet = [
                        'RamShareArn'
                    ],
                    ConsistentRead=True
                )

                if response['Item']['RamShareArn']:
                    print("\n%s has been shared with secondary accounts..." % tgw_id)
            except:
                def take_action():
                    action_to_take = raw_input("\nIt does not appear that the TGW has been shared with\n"
                                            "registered secondary accounts yet. Do you want to do that\n"
                                            "now? Choose 'Y' or 'N'\n"
                                            "-------------------------------------------------\n"
                                            "n\\Y> ") or "Y"
                    if action_to_take.lower() == 'y':
                        create_ram(table,tgw_id)
                        return action_to_take.lower()
                    elif action_to_take.lower() == 'n':
                        return action_to_take.lower()
                    else:
                        print('\nPlease choose a valid option: \'Y\' or \'N\'..')
                        take_action()
                action_to_take = take_action()        
                if action_to_take == 'n':
                    return
                
            # Attach VPCs in parent account
            ec2_c = boto3.client('ec2', region_name = region)
            ec2_r = boto3.resource('ec2', region_name = region)
            print("\nAttaching VPCs in %s" % "parent account")
            vpc_attachments.update(attach_tagged_vpcs(ec2_c,ec2_r,cgw,'parent account',table,tgw_id,vpc_attachments))
            attach_vpcs(ec2_c,ec2_r,cgw,'parent account',table,tgw_id)

            # Attach VPCs in secondary accounts
            for account in accounts:
                if account != '':
                    try:
                        creds = get_account_creds(account)
                        print("\nAttaching VPCs in account %s" % account)
                        vpc_attachments.update(attach_tagged_vpcs(creds[0],creds[1],cgw,account,table,tgw_id,vpc_attachments))
                        attach_vpcs(creds[0],creds[1],cgw,account,table,tgw_id)
                    except:
                        print("\nThere was an issue with accessing account %s.\n"
                            "Please check its permissions" % account)

            # Check status of VPCs in parent account
            ec2_c = boto3.client('ec2', region_name = region)
            ec2_r = boto3.resource('ec2', region_name = region)
            check_status(ec2_c,ec2_r,cgw,'parent account',table,tgw_id)
            
            # Check status of VPCs in secondary accounts
            for account in accounts:
                if account != '':
                    try:
                        creds = get_account_creds(account)
                        check_status(creds[0],creds[1],cgw,account,table,tgw_id)
                    except:
                        pass

    elif user_response.lower() == 'n':
        cgw = '1.1.1.1'
        print("\nSkipping any transit-vpc to TGW migration...")

       
        # Check if there are any secondary AWS accounts with spoke VPCs that need to be attached
        with open('dependencies/accounts.txt','r') as f:
            accounts = f.read()
        accounts = accounts.replace('-','').replace(' ','').replace('\n','')
        accounts = accounts.split(',')

        def get_account_creds(account):
            # Assume role for secondary account
            sts = boto3.client('sts',region_name=region)
            creds = sts.assume_role(
                RoleArn='arn:aws:iam::' + account + ':role/TgwMigratorCrossAccountAccess',
                RoleSessionName='TgwMigratorUpdateDb'
            )

            # Use the retrieved creds above to make API calls
            ec2_c = boto3.client('ec2',
                    region_name = region,
                    aws_access_key_id = creds['Credentials']['AccessKeyId'],
                    aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                    aws_session_token = creds['Credentials']['SessionToken']
                    )
            ec2_r = boto3.resource('ec2',
                    region_name = region,
                    aws_access_key_id = creds['Credentials']['AccessKeyId'],
                    aws_secret_access_key = creds['Credentials']['SecretAccessKey'],
                    aws_session_token = creds['Credentials']['SessionToken']
                    )
            return ec2_c, ec2_r
        
        if accounts[0] == '' and len(accounts) < 2:
            # There are no secondary accounts.
            # Attach VPCs in parent account
            print("\nAttaching VPCs in %s" % 'parent account')
            ec2_c = boto3.client('ec2', region_name = region)
            ec2_r = boto3.resource('ec2', region_name = region)
            vpc_attachments.update(attach_tagged_vpcs(ec2_c,ec2_r,cgw,'parent account',table,tgw_id,vpc_attachments))

            # Check status of VPCs in parent account
            ec2_c = boto3.client('ec2', region_name = region)
            ec2_r = boto3.resource('ec2', region_name = region)
            check_status(ec2_c,ec2_r,cgw,'parent account',table,tgw_id)
            
        else:
            try:
                response = table.get_item(
                    Key = {
                        'VpcId' : 'vpc-xxxx'
                    },
                    AttributesToGet = [
                        'RamShareArn'
                    ],
                    ConsistentRead=True
                )

                if response['Item']['RamShareArn']:
                    print("\n%s has been shared with secondary accounts..." % tgw_id)
            except:
                def take_action():
                    action_to_take = raw_input("\nIt does not appear that the TGW has been shared with\n"
                                            "registered secondary accounts yet. Do you want to do that\n"
                                            "now? Choose 'Y' or 'N'\n"
                                            "-------------------------------------------------\n"
                                            "n\\Y> ") or "Y"
                    if action_to_take.lower() == 'y':
                        create_ram(table,tgw_id)
                        return action_to_take.lower()
                    elif action_to_take.lower() == 'n':
                        return action_to_take.lower()
                    else:
                        print('\nPlease choose a valid option: \'Y\' or \'N\'..')
                        take_action()
                action_to_take = take_action()        
                if action_to_take == 'n':
                    return
                
            # Attach VPCs in parent account
            ec2_c = boto3.client('ec2', region_name = region)
            ec2_r = boto3.resource('ec2', region_name = region)
            print("\nAttaching VPCs in %s" % "parent account")
            vpc_attachments.update(attach_tagged_vpcs(ec2_c,ec2_r,cgw,'parent account',table,tgw_id,vpc_attachments))

            # Attach VPCs in secondary accounts
            for account in accounts:
                if account != '':
                    try:
                        creds = get_account_creds(account)
                        print("\nAttaching VPCs in account %s" % account)
                        vpc_attachments.update(attach_tagged_vpcs(creds[0],creds[1],cgw,account,table,tgw_id,vpc_attachments))
                    except:
                        print("\nThere was an issue with accessing account %s.\n"
                            "Please check its permissions" % account)

            # Check status of VPCs in parent account
            ec2_c = boto3.client('ec2', region_name = region)
            ec2_r = boto3.resource('ec2', region_name = region)
            check_status(ec2_c,ec2_r,cgw,'parent account',table,tgw_id)
            
            # Check status of VPCs in secondary accounts
            for account in accounts:
                if account != '':
                    try:
                        creds = get_account_creds(account)
                        check_status(creds[0],creds[1],cgw,account,table,tgw_id)
                    except:
                        pass

    else:
        print("\nYou must choose 'Y' or 'N' for the question above")
        attach_spoke_vpcs(table,tgw_id)